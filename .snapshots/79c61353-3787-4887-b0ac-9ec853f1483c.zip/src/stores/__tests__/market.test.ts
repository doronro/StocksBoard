import { describe, it, expect, beforeEach } from 'vitest'
import { useMarketStore } from '../market'
import { Quote } from '@types/index'

describe('Market Store', () => {
  beforeEach(() => {
    const store = useMarketStore.getState()
    store.clearQuotes()
  })

  it('Should initialize with empty quotes', () => {
    const store = useMarketStore.getState()
    expect(store.quotes.size).toBe(0)
  })

  it('Should update a single quote', () => {
    const store = useMarketStore.getState()
    const quote: Quote = {
      symbol: 'AAPL',
      name: 'Apple Inc.',
      price: 150,
      change: 2.5,
      changePercent: 1.7,
      bid: 149.9,
      ask: 150.1,
      volume: 50000000,
      avgVolume: 40000000,
      timestamp: Date.now(),
      trend: 'up',
    }

    store.updateQuote(quote)
    expect(store.quotes.size).toBe(1)
    expect(store.getQuote('AAPL')).toEqual(quote)
  })

  it('Should update multiple quotes', () => {
    const store = useMarketStore.getState()
    const quotes: Quote[] = [
      {
        symbol: 'AAPL',
        name: 'Apple Inc.',
        price: 150,
        change: 2.5,
        changePercent: 1.7,
        bid: 149.9,
        ask: 150.1,
        volume: 50000000,
        avgVolume: 40000000,
        timestamp: Date.now(),
        trend: 'up',
      },
      {
        symbol: 'MSFT',
        name: 'Microsoft',
        price: 300,
        change: -1,
        changePercent: -0.33,
        bid: 299.9,
        ask: 300.1,
        volume: 30000000,
        avgVolume: 35000000,
        timestamp: Date.now(),
        trend: 'down',
      },
    ]

    store.updateQuotes(quotes)
    expect(store.quotes.size).toBe(2)
    expect(store.getQuote('AAPL')).toBeDefined()
    expect(store.getQuote('MSFT')).toBeDefined()
  })

  it('Should set market status', () => {
    const store = useMarketStore.getState()
    store.setMarketStatus('open')
    expect(store.marketStatus).toBe('open')

    store.setMarketStatus('closed')
    expect(store.marketStatus).toBe('closed')
  })

  it('Should set selected symbol', () => {
    const store = useMarketStore.getState()
    store.setSelectedSymbol('AAPL')
    expect(store.selectedSymbol).toBe('AAPL')

    store.setSelectedSymbol(null)
    expect(store.selectedSymbol).toBeNull()
  })

  it('Should return undefined for non-existent quote', () => {
    const store = useMarketStore.getState()
    expect(store.getQuote('NONEXISTENT')).toBeUndefined()
  })

  it('Should update last update timestamp', () => {
    const store = useMarketStore.getState()
    const beforeTime = store.lastUpdate
    const quote: Quote = {
      symbol: 'AAPL',
      name: 'Apple Inc.',
      price: 150,
      change: 2.5,
      changePercent: 1.7,
      bid: 149.9,
      ask: 150.1,
      volume: 50000000,
      avgVolume: 40000000,
      timestamp: Date.now(),
      trend: 'up',
    }

    store.updateQuote(quote)
    expect(store.lastUpdate).toBeGreaterThanOrEqual(beforeTime)
  })

  it('Should clear all quotes', () => {
    const store = useMarketStore.getState()
    const quote: Quote = {
      symbol: 'AAPL',
      name: 'Apple Inc.',
      price: 150,
      change: 2.5,
      changePercent: 1.7,
      bid: 149.9,
      ask: 150.1,
      volume: 50000000,
      avgVolume: 40000000,
      timestamp: Date.now(),
      trend: 'up',
    }

    store.updateQuote(quote)
    expect(store.quotes.size).toBe(1)

    store.clearQuotes()
    expect(store.quotes.size).toBe(0)
  })
})
